function Footer ({footer}) {
        return (
            <div>
                <h5>{footer}</h5>
            </div>
        )
}

export default Footer;