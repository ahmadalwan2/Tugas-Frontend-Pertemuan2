function About({ about }) {
    return (
        <div>
            <h5>{about}</h5>
        </div>
    )
}

export default About;